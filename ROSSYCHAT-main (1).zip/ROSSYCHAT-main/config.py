from os import getenv

from dotenv import load_dotenv

load_dotenv()

API_ID = "24509589"
# -------------------------------------------------------------
API_HASH = "717cf21d94c4934bcbe1eaa1ad86ae75"
# --------------------------------------------------------------
BOT_TOKEN = getenv("BOT_TOKEN", None)
MONGO_URL = getenv("MONGO_URL", None)
OWNER_ID = "6358262816"
SUPPORT_GRP = "BABYBOTSX"
UPDATE_CHNL = "BABYUPDATE"
OWNER_USERNAME = "VM_COOL"

